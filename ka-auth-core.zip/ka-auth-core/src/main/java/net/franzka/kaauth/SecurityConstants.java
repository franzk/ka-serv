package net.franzka.kaauth;

public class SecurityConstants {
    public static final String SCOPE_MAILER_SEND = "SCOPE_mailer:send";
    public static final String SCOPE_BACK_ACCESS = "SCOPE_back:access";
}
